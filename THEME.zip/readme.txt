﻿En cas de bugs/remarques, contactez
moi par mail (twiinkx@outlook.fr).

Changelogs 1.0.7:
- Background progressbar
- Rectification CSS (succes, dis job)
- Refonte mineur interface